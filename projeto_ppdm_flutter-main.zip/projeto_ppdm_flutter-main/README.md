# Parte 1: Respostas Conceituais

## 1. Nativo vs. Cross-Platform/Híbrido (Flutter)

No desenvolvimento **nativo**, cada plataforma tem sua própria base de código,
linguagem e SDK (Kotlin/Java para Android, Swift para iOS). O resultado usa
diretamente os componentes de interface do sistema, com acesso total e imediato
aos recursos do dispositivo, mas exige duas bases de código e, geralmente, duas equipes.

No **cross-platform** (Flutter), existe uma única base de código em Dart, compilada
para várias plataformas. O Flutter não usa os componentes nativos do sistema: ele
desenha toda a interface com seu próprio motor de renderização. Isso garante
aparência consistente e reduz tempo e custo de desenvolvimento, em troca de
depender do framework e de plugins para acessar recursos específicos de cada plataforma.

## 2. StatelessWidget vs. StatefulWidget

- **StatelessWidget**: widget imutável, que não guarda estado interno. Sua
  aparência depende apenas das informações recebidas na construção e não muda
  sozinha. **Exemplo:** um título (`Text`), um ícone, ou um cartão de perfil com
  dados fixos.
- **StatefulWidget**: widget que possui um objeto `State` mantido entre
  reconstruções, permitindo que a interface mude em resposta a eventos.
  **Exemplo:** um contador com botão, um checkbox, um formulário que reage ao
  que o usuário digita.

Regra prática: se a tela precisa mudar depois de construída, use Stateful;
caso contrário, use Stateless.

## 3. O que acontece ao chamar setState()

O `setState()` avisa o framework de que o estado interno do widget mudou. O
Flutter marca o widget como "sujo" e agenda uma nova chamada ao método `build()`
no próximo frame. A árvore de widgets é reconstruída, e apenas as partes que
realmente mudaram são redesenhadas na tela. Sem `setState()`, o valor da
variável pode até mudar, mas a interface não é atualizada.
